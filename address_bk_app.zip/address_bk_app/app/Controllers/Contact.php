<?php

namespace App\Controllers;	
use App\Models\ContactModel;

class Contact extends BaseController
{
	public function __construct(){
		$this->model = new ContactModel();
	}
    public function index()
    {
		$data['cResult'] = $this->model->getContactList();
        return view('contact_list',$data);
    }
	
	public function add(){ 
		if($this->request->getVar('param')=="update"){
			$data['page_title'] = 'Update';
			$id = base64_decode($this->request->getVar('id'));
			$data['id'] = $id;
			$data['rowData'] = $this->model->getRowData($id);
		} else {
			$data['page_title'] = 'Add';
		}
		return view('ajax_contact_form',$data);
	}
	
	public function getSaveData(){ //print_r($_POST); exit;
		$data['first_name'] =  $this->request->getVar('first_name'); 
		$data['last_name'] =  $this->request->getVar('last_name'); 
		$data['dob'] =  $this->request->getVar('dob'); 
		$data['contact_mobile'] =  $this->request->getVar('contact_mobile'); 
		$data['contact_phone'] =  $this->request->getVar('contact_phone'); 
		$data['email'] =  $this->request->getVar('email'); 
		$data['street'] =  $this->request->getVar('street'); 
		$data['city'] =  $this->request->getVar('city'); 
		if($this->request->getVar('hobbies')){
			$data['hobbies'] =  implode(',',$this->request->getVar('hobbies')); 
		} else {
			$data['hobbies'] = '';
		}
		if($this->request->getVar('edit_id')!=''){
			$id = $this->request->getVar('edit_id');
			$this->model->updateData('address_bk',$data,'id',$id);
			echo 2;
		} else {
			$data['created_date'] = date('Y-m-d H:i:s'); 
			$this->model->insertData('address_bk',$data);
			echo 1;
		}
		
	}
	
	public function getDeleteData(){
		$id = $this->request->getVar('id');
		$data['status'] = 0;
		$this->model->deleteData('address_bk',$data,'id',$id);
		echo 1;	
	}
	
	public function sendMail(){
		$subject = 'Test Mail';
		$msg = 'Dear User,\n';
		$msg .= 'This is test content';
		$header = "From:durgaani.r@gmail.com \r\n";
		$header .= "MIME-Version: 1.0\r\n";
		$header .= "Content-type: text/html\r\n";
		$to = "ilam.a@emphaticsense.com";
		$retval = mail ($to,$subject,$msg,$header);
		echo 1;
	}
}
?>
