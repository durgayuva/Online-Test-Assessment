<?php
    namespace Config;
    
    use CodeIgniter\Config\BaseConfig;
    
    class MyConfig extends BaseConfig
    {
        public $cityNames = array('Paris','London','Athens','Madrid',"Gudalur","Hosur");
        public $ada_site_name = 'Site name';
    }
?>