<!DOCTYPE html>
<html>
<title>Address Book List</title>
<head>
  <meta charset="UTF-8">
  <meta name="Address Book List" content="Sample Crud Operations">
  <meta name="keywords" content="HTML, CSS, JavaScript">
  <meta name="author" content="Durgadevi">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css"/>
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.4/css/buttons.dataTables.min.css">
    <link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" />
	
<style>
.error{
	color:red;
}
</style>	
</head>
<body>
<div class="row">
<div class="col-md-12">
<h4>Contact List</h4>
<div style="float:right;margin:10px;">
	<a href="javascript:void(0);" class="btn btn-primary" onclick="getRequestData('update','');" id="btn_add" name="btn_add">ADD</a>
	<a href="javascript:void(0);" class="btn btn-danger"  id="btn_delete" name="btn_delete">Delete</a>
	<a href="javascript:void(0);" class="btn btn-primary"  id="btn_mail" name="btn_mail">Send Email</a>
</div>
<br/>
<div style="clear:both;"></div>
<div class="table-responsive">
	<table class="table table-bordered" id="contact_table">
		<thead>
			<tr>
				<th>Sl.No</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Email</th>
				<th>Address</th>
				<th>DOB</th>
				<th>Mobile</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php $i=1; if($cResult){
				foreach($cResult as $res) { ?>
					<tr>
						<td><input type="checkbox" class="checkData" name="idData[]" id="idData" value="<?php echo $res['id']; ?>"><?=$i;?></td>
						<td><?php echo $res['first_name']; ?></td>
						<td><?php echo $res['last_name']; ?></td>
						<td><?php echo $res['email']; ?></td>
						<td><?php echo $res['street']. " , ".$res['city']; ?></td>
						<td><?php echo $res['dob']; ?></td>
						<td><?php echo $res['contact_mobile']; ?></td>
						<td><a href="javascript:void(0);" id="btn_update" name="btn_update" onclick="getRequestData('update',<?php echo "'".base64_encode($res['id'])."'"?>);">Edit</a></td>
					</tr>
			<?php $i++; } 
			}?>			
		</tbody>
	</table>
</div>
</div>
</div>

<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.4/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.4/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.4/js/buttons.print.min.js"></script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/additional-methods.js"></script>


<input type="hidden" name="base_url" id="base_url" value="<?php echo base_url();?>"/>
<div class="modal" id="myModal" tabindex="-1" role="dialog" style="width:70%">
  <div class="modal-dialog" role="document" style="width:70%">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Contact Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function() {
    $('#contact_table').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
	
	
} );

 

function getRequestData(param,id){
	var baseurl = $('#base_url').val();
	$.ajax({
		'type':'POST',
		'url':baseurl+'/getpopupData',
		'data':{"param":param,"id":id},
		success: function(response) {
			  $('#myModal').modal({ backdrop: "static ", keyboard: false });
			 $('#myModal .modal-body').html(response);
			
		}
	});
	
};

$('#btn_cancel').click(function(){
	$("#myModal").modal("hide");
});

$('#btn_delete').click(function(){
	var ids =[];
	var dd =0;
	
	$(".checkData").each(function(i){
		if ($(this).prop('checked')==true){ 
			ids[i] = $(this).val();
			dd++;
		} 
	});
	
	if(dd>0){
		var confirmD = confirm("Are you sure want to delete the data?");
		if(confirmD){
			var baseurl = $('#base_url').val();
			$.ajax({
				'type':'POST',
				'url':baseurl+'/deleteData',
				'data':{"id":ids},
				success: function(response) {
					if(response == 1){
						alert('Data Deleted Successfully.');
						window.location.reload();
					} else {
						alert('Error while deleting data.');
					}
				}
			});
		}
	}	else {
			alert("Please select at least one record.");
			return false;
		}			
	
});

$('#btn_mail').click(function(){
	
	var confirmD = confirm("Are you sure want to sent a mail?");
	if(confirmD){
		var baseurl = $('#base_url').val();
		$.ajax({
			'type':'get',
			'url':baseurl+'/sendMail',
			//'data':{"id":ids},
			error:function(error){
				console.log(error.statusText);
				//alert(error.message);
			},
			success: function(response) {
				if(response == 1){
					alert('Mail Sent Successfully.');
					window.location.reload();
				} else {
					alert('Error while sending mail.');
				}
			}
		});
	}
	
});



</script>



</body>
</html>