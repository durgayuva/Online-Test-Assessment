<form id="contact_form" name="contact_form" enctype="multipart/form-data">
	<label>First Name <span class="error">*</span></label>
	<input type="text" name="first_name" class="form-control" id="first_name" required  maxlength="30" value="<?php if(isset($rowData) && $rowData['first_name']!=''){ echo $rowData['first_name']; } ?>"/>
	
	<label>Last Name <span class="error">*</span></label>
	<input type="text" name="last_name" class="form-control" id="last_name" required  maxlength="30" value="<?php if(isset($rowData) && $rowData['last_name']!=''){ echo $rowData['last_name']; } ?>"/>
	
	<label>DOB <span class="error">*</span></label>
	<input type="date" name="dob" class="form-control" id="dob"  max="2015-12-31"  required value="<?php if(isset($rowData) && $rowData['dob']!=''){ echo $rowData['dob']; } ?>"/>
	
	<label>Gender <span class="error">*</span></label>
	<div class="form-group">
	<input type="radio" required id="gender" name="gender" <?php if(isset($rowData) && $rowData['gender'] =='Male'){ echo 'checked'; } ?> value="male"> Male 
	<input required type="radio" id="gender" name="gender" <?php if(isset($rowData) && $rowData['gender'] =='Female'){ echo 'checked'; } ?> value="female"> Female
	</div>	
	
	<label>Contact Mobile <span class="error">*</span></label>
	<input type="number" name="contact_mobile" class="form-control" id="contact_mobile" required minlength="10" maxlength="16" value="<?php if(isset($rowData) && $rowData['contact_mobile']!=''){ echo $rowData['contact_mobile']; } ?>"/>
	
	<label>Contact Phone</label>
	<input type="number" name="contact_phone" class="form-control" id="contact_phone" minlength="10" maxlength="16" value="<?php if(isset($rowData) && $rowData['contact_phone']!=''){ echo $rowData['contact_phone']; } ?>"/>
	
	<label>Email <span class="error">*</span></label>
	<input type="email" name="email" class="form-control" id="email" required maxlength="120" value="<?php if(isset($rowData) && $rowData['email']!=''){ echo $rowData['email']; } ?>"/>
	<span id="invalid_email" class="error">Invalid Email Address</span>
	
	<label>Street</label>
	<input type="text" name="street" class="form-control" id="street" maxlength="120" value="<?php if(isset($rowData) && $rowData['street']!=''){ echo $rowData['street']; } ?>"/>
	
	<label>City</label>
	<?php $cityNames = array('Paris','London','Athens','Madrid',"Gudalur","Hosur"); ?>
	<select id="city" name="city" class="form-control">
		<option value="">Select City</option>
		<?php foreach($cityNames as $c):?>
			<option <?php if(isset($rowData) && $rowData['city']==$c){ echo 'selected';}?> value="<?=$c;?>"><?=$c;?></option>
		<?php endforeach; ?>
	</select>
	
	<label>Hobbies</label>
	<?php $hobbies = array('Playing','Dancing','Music','Cricket',"Singing","Reading"); ?>
	<select id="hobbies" name="hobbies[]" class="form-control" multiple="multiple">
		<option value="">Select Hobbies</option>
		<?php foreach($hobbies as $h):?>
			<?php if(isset($rowData) && in_array($h,explode(',',$rowData['hobbies']))){ ?>
				<option selected="selected" value="<?=$h;?>"><?=$h;?></option>
			<?php } else { ?>
				<option value="<?=$h;?>"><?=$h;?></option>
			<?php } ?>
		<?php endforeach; ?>
	</select>
	<br/><br/>
	<input type="hidden" id="edit_id" name="edit_id" value="<?php if(isset($rowData) && $rowData['id']){ echo $rowData['id']; }else { echo '';}?>"/>
	<div class="form-group">
	<button type="button" name="btn_submit" class="btn btn-primary" id="btn_submit">Submit</button>
	<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
	</div>
	
</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/additional-methods.js"></script>
<script>
$(function() {
	$('#invalid_email').hide();
	$('#btn_submit').click(function(){
		var valid= 0;
		var firstname = $('#first_name').val();
		var last_name = $('#last_name').val();
		var dob = $('#dob').val();
		var contact_mobile = $('#contact_mobile').val();
		var email = $('#email').val();
		
		if(firstname ==''){
			valid++;
		}
		
		if(last_name ==''){
			valid++;
		}
		
		if(dob ==''){
			valid++;
		}
		
		if(contact_mobile ==''){
			valid++;
		}
		
		if(email ==''){
			valid++;
		}
		
		
		if ($("#gender").is(":checked")) {
			
		} else {
			valid++;
		}
		
		if(email!='' && IsEmail(email)==false){
			valid++;
			$('#invalid_email').show();
			return false;
		}	
		
		if(email!='' && contact_mobile!='' && dob!='' && last_name!='' && firstname!='' && $("#gender").is(":checked")){
			valid =0;
		}
		if(valid>1){
			alert('The fields marked as * are required. Please fill the fields.');
			return false;
		} else {
			var confirmD = confirm("Are you sure want to submit the data?");
			if(confirmD){
				var baseurl = $('#base_url').val();
				$.ajax({
					'type':'POST',
					'url':baseurl+'/saveform',
					'data':$('#contact_form').serialize(),
					success: function(response) {
						if(response == 1){
							alert('Data Saved Successfully.');
							window.location.reload();
						} else if(response == 2){
							alert('Data Updated Successfully.');
							window.location.reload();
						} else {
							alert('Error while inserting data.');
						}
					}
				});
			}
		}
    });
	
	 function IsEmail(email) {
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(email)) {
           return false;
        }else{
           return true;
        }
      }
	
	
});
</script>