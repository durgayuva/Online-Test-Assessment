<form id="contact_form" name="contact_form" enctype="multipart/form-data">
	<label>First Name</label>
	<input type="text" name="first_name" id="first_name"/>
	
	<label>Last Name</label>
	<input type="text" name="last_name" id="last_name"/>
	
	<label>DOB</label>
	<input type="date" name="dob" id="dob"/>
	
	<label>Gender</label>
	<input type="radio" name="gender" value="male"> Male <input type="radio" name="gender" value="female"> Female
	
	<label>Contact Mobile</label>
	<input type="number" name="contact_mobile" id="contact_mobile"/>
	
	<label>Contact Phone</label>
	<input type="number" name="contact_phone" id="contact_phone"/>
	
	<label>Email</label>
	<input type="email" name="email" id="email"/>
	
	<label>Street</label>
	<input type="text" name="street" id="street"/>
	
	<label>City</label>
	<?php $cityNames = array('Paris','London','Athens','Madrid',"Gudalur","Hosur"); ?>
	<select id="city" name="city">
		<?php foreach($cityNames as $c):?>
			<option value="<?=$c;?>"><?=$c;?></option>
		<?php endforeach; ?>
	</select>
	
	<label>Hobbies</label>
	<?php $hobbies = array('Playing','Dancing','Music','Cricket',"Singing","Reading"); ?>
	<select id="hobbies" name="hobbies">
		<?php foreach($hobbies as $h):?>
			<option value="<?=$h;?>"><?=$h;?></option>
		<?php endforeach; ?>
	</select>
	
	<button type="button" name="btn_submit" id="btn_submit">Submit</button>
	<button type="button" name="btn_cancel" id="btn_cancel">Cancel</button>
</form>