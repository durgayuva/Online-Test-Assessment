<?php
namespace App\Models;

use CodeIgniter\Model;
class ContactModel extends Model
{
	protected $DBGroup = 'default';
    public function getContactList(){
		$builder = $this->db->table('address_bk');
		$builder->where('status',1);
		$query   = $builder->get();
		$results = $query->getResultArray();
		return $results;
	}
	
	public function insertData($tbl,$data){
		$builder = $this->db->table($tbl);
		$builder->insert($data);
		return $this->db->insertID();
	}
	
	public function getRowData($id){
		$builder = $this->db->table('address_bk');
		$builder->where('id',$id);
		$query   = $builder->get();
		$row = $query->getRowArray();
		return $row;
	}
	
	public function updateData($tbl,$data,$field,$val){
		$builder = $this->db->table($tbl);
		$builder->where($field, $val);
		$builder->update($data);
		return $val;
	}
	
	public function deleteData($tbl,$data,$field,$val){
		$builder = $this->db->table($tbl);
		$builder->whereIn($field, $val);
		$builder->update($data);
		return $val;
	}
}
?>